import React from "react";
import { Link } from "react-router-dom";
import "./aboutme.css";

function AboutMe() {
  return (
    <div id="header">
      <div className="container">
        <nav>
          <img src="images/logo.png" className="logo" alt="Logo" />
          <ul>
            <li><Link to="/landing">Home</Link></li>
            <li><Link to="/">About Me</Link></li>
            <li><Link to="/projects">My Projects</Link></li>
          </ul>
        </nav>
        <div className="header-text">
          <h1>My name is <span>Kenny Wu</span></h1>
          <p>I'm a high school student at Diamond Bar High.<br />I'm part of the Future Business Leader of America Club in school.</p>
          <p>Interests:</p>
          <ul>
            <li>Music</li>
            <li>Food</li>
            <li>Art</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default AboutMe;