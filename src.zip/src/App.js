import React from "react";
import { Link, Route, Routes } from "react-router-dom";
import AboutMe from "./pages/AboutMe/aboutme";
import Projects from "./pages/Projects/projects";
import './App.css';
function App() {
  return (
    <div id="header">
      <div className="container">
        <nav>
          <img src="images/logo.png" className="logo" alt="Logo" />
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About Me</Link></li>
            <li><Link to="/projects">Projects</Link></li>
          </ul>
        </nav>
        <Routes>
          <Route path="/" element={<App />} />
          <Route path="/about" element={<AboutMe />} />
          <Route path="/projects" element={<Projects />} />
        </Routes>
        <div className="header-text">
          <h1>Hi, I'm <span>Kenny</span></h1>
          <p>I'm a 16 years old high school student<br />hoping to major in some part of the CS branch.<br />I'm capable of coding in Python and c++.</p>
          <p>Hobbies:</p>
          <ul>
            <li>Basketball</li>
            <li>Snowboarding</li>
            <li>Piano</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;
